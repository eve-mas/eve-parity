Generators.run_command_line_generator "laddergame";;

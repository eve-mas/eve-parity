let register _ =
    Zadehexp.register();
    Cunninghamexp.register();
    Zadehsubexp.register();
    Cunninghamsubexp.register();
    Fearnleysubexp.register();
    Friedmannsubexp.register();
    Switchallsubexp.register();
    Switchbestsubexp.register();
    Switchallexp.register();
    Switchbestexp.register();
    Randomfacetsubexp.register();
    Randomedgesubexp.register();
    Randomedgeexptest.register();;